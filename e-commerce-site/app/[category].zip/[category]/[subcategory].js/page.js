"use client"
import { useParams } from 'next/navigation';
import { useEffect, useState } from 'react';

export default function Page() {
    const params = useParams();
    // const navigation = useNavigation();
    const { category, subcategory } = params;
    const [product, setProduct] = useState(["loading"]);

    useEffect(() => {
        // Fetch or perform any operations with the product data here
    }, [subcategory, category]);

    return (
        <section className='pt-32 px-16'>
            <h2>id: {subcategory + category}</h2>
            {/* Add any other UI elements as needed */}
        </section>
    )
}
